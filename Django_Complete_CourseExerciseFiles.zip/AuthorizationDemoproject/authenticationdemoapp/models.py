# from django.db import models

# # Create your models here.
# from django.contrib.auth.models import AbstractUser
# from django.db import models

# class CustomUser(AbstractUser):    

#     COUNTRY_CHOICES = [
#         ('US', 'United States'),
#         ('UK', 'United Kingdom'),
#         ('IN', 'India'),
#         ('AU', 'Australia'),
        
#     ]

#     country = models.CharField(max_length=2, choices=COUNTRY_CHOICES)
#     address = models.CharField(max_length=30, blank=True)


from django.contrib.auth.models import AbstractUser, Group,Permission
from django.db import models

class CustomPermission(models.Model):
    permission = models.OneToOneField(Permission, on_delete=models.CASCADE, primary_key=True)

    def __str__(self):
        return self.permission.name
    
    class Meta:
        permissions = (
            ("add_staffuser", "Can add staff users"),
            ("change_staffuser", "Can edit staff users"),
            ("view_staffuser", "Can view staff users"),
            ("delete_staffuser", "Can delete staff users"),

        )
