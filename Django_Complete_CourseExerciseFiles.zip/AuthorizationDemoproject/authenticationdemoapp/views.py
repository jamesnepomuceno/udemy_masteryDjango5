from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm,PasswordChangeForm,UserChangeForm
from authenticationdemoapp.forms import CreateStaffEmployeeForm, EditStaffEmployeeForm, RoleForm, SignUpForm,ChangeProfileForm
from django.contrib.auth import login,logout,authenticate,update_session_auth_hash
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib.auth.models import Group,User,Permission
from django.contrib import messages

# Create your views here.


def signup(request):
    #form = UserCreationForm()
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()  

            # Add user to the 'Customers' group
            customers_group, created = Group.objects.get_or_create(name='Customers')
            user.groups.add(customers_group)             
            

            login(request, user)
            return redirect('home')  # Redirect to home or any other desired page
    else:
        form=SignUpForm()
    return render(request, 'authenticationdemoapp/signup.html', {'form': form})

@login_required
def home(request):
    return render(request, 'authenticationdemoapp/home.html')


def login_view(request):
    if request.method == 'POST':
            form = AuthenticationForm(request, data=request.POST)
            if form.is_valid():
                username = form.cleaned_data.get('username')
                password = form.cleaned_data.get('password')
                user = authenticate(request, username=username, password=password)

                if user is not None:
                    login(request, user)
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'authenticationdemoapp/login.html', {'form': form})


@login_required
def change_password(request):

     if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important to maintain the session
            return redirect('home')
     else:
        form = PasswordChangeForm(request.user)
    
     return render(request, 'authenticationdemoapp/change_password.html', {'form': form})


@login_required
def change_profile(request):

     if request.method == 'POST':
        form = ChangeProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('home')
     else:
    #form = UserChangeForm(instance=request.user)
        form = ChangeProfileForm(instance=request.user)

     return render(request, 'authenticationdemoapp/change_profile.html', {'form': form})


@login_required
def delete_account(request):
    if request.method == 'POST':
        request.user.delete()
        return redirect('login')  # Redirect to signup after account deletion
    return render(request, 'authenticationdemoapp/delete_account.html')


@login_required
def signout(request):
    logout(request)
    return redirect('login')


def is_superuser(user):
    return user.is_superuser

@login_required
@user_passes_test(is_superuser)
def roles_list(request):
    roles = Group.objects.all()
    return render(request, 'authenticationdemoapp/roles_list.html', {'roles': roles})


@login_required
@user_passes_test(is_superuser)
def create_role(request):
      if request.method == 'POST':
        form = RoleForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('roles_list')
      else:
        form = RoleForm()
      return render(request, 'authenticationdemoapp/create_role.html', {'form': form})


@login_required
@user_passes_test(is_superuser)
def edit_role(request, role_id):
     role = Group.objects.get(pk=role_id)

     if request.method == 'POST':
        form = RoleForm(request.POST, instance=role)
        if form.is_valid():
            role = form.save()         
            return redirect('roles_list')
     else:        
        form = RoleForm(instance=role)
     return render(request, 'authenticationdemoapp/edit_role.html', {'form': form, 'role': role})


@login_required
@user_passes_test(is_superuser)
def delete_role(request, role_id):
    role = Group.objects.get(pk=role_id)
    
    GroupUsers = User.objects.filter(groups__name=role).count()
   
    if(GroupUsers == 0):
        role.delete()
        return redirect('roles_list')
    else:
        ErrorMessage="This Role cannot be deleted..as it has Users!"
        return HttpResponse(ErrorMessage)
    
from functools import wraps


def user_has_role_or_superuser(roles):
    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def _wrapped_view(request, *args, **kwargs):
            user_groups = request.user.groups.all().values_list('name', flat=True)
            
            if request.user.is_superuser or any(role in user_groups for role in roles):
                return view_func(request, *args, **kwargs)
            else:
                return redirect("home")
        return _wrapped_view
    return decorator


@login_required
#@user_passes_test(is_superuser)
@user_has_role_or_superuser(['HR', 'SeniorHR', 'Directors'])
def staff_list(request):
    staff_members = User.objects.filter(is_staff=True)

    user_groups = request.user.groups.all().values_list('name', flat=True)
    return render(request, 'authenticationdemoapp/staff_list.html', {'staff_members': staff_members, 'user': request.user, 'user_groups': user_groups})

    #return render(request, 'authenticationdemoapp/staff_list.html', {'staff_members': staff_members})


@login_required
#@user_passes_test(is_superuser)
@user_has_role_or_superuser(['HR'])
def create_staff_employee(request):

    if request.method == 'POST':
        form = CreateStaffEmployeeForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_staff = True
            user.save()

            rolename = form.cleaned_data.get('role')
            staff_group, created = Group.objects.get_or_create(name=rolename)
            user.groups.add(staff_group)      


            return redirect('staff_list')
    else:
        form = CreateStaffEmployeeForm()

    return render(request, 'authenticationdemoapp/create_staff_employee.html', {'form': form})


@login_required
#@user_passes_test(is_superuser)
@user_has_role_or_superuser(['SeniorHR'])
def edit_staff_employee(request, user_id):      
    staff_member = User.objects.get(pk=user_id)

    if request.method == 'POST':
        form = EditStaffEmployeeForm(request.POST, instance=staff_member)
        if form.is_valid():
            user = form.save()

            rolename = form.cleaned_data.get('role')
            staff_group, created = Group.objects.get_or_create(name=rolename)
            user.groups.clear()
            user.groups.add(staff_group)               

            return redirect('staff_list')
    else:
        groupname = staff_member.groups.values_list('name', flat=True).first()  
        staff_group = Group.objects.get(name=groupname)      
        form = EditStaffEmployeeForm(instance=staff_member)
    
    return render(request, 'authenticationdemoapp/edit_staff_employee.html', 
                  {'form': form, 'staff_member': staff_member,'staff_group':staff_group})



@login_required
#@user_passes_test(is_superuser)
@user_has_role_or_superuser(['Directors'])
def delete_staff_employee(request, user_id):
    staff_member = User.objects.get(pk=user_id)
    staff_member.delete()
    return redirect('staff_list')


@login_required
@user_passes_test(is_superuser)
def associate_permissions(request, role_id):
    role = Group.objects.get(pk=role_id)   
    relevant_permissions = ['view_staffuser', 'change_staffuser', 'delete_staffuser', 'add_staffuser']

    if request.method == 'POST':
        try:
            selected_permission_ids = request.POST.getlist('permissions')
            selected_permissions = Permission.objects.filter(pk__in=selected_permission_ids)

            role.permissions.set(selected_permissions)

            messages.success(request, "Permissions associated successfully!")
            return redirect('roles_list')

        except Exception as e:
            print(f"Error associating permissions: {e}")
            messages.error(request, "An error occurred while associating permissions. Please try again.")
    else:           
         all_permissions = Permission.objects.filter(codename__in=relevant_permissions)           

    return render(request, 'authenticationdemoapp/associate_permissions.html', 
                  {'role': role, 'all_permissions': all_permissions})


# Creating Custom Decorator

