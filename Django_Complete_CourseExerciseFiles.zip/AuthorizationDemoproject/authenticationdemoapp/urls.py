

from django.urls import path
from authenticationdemoapp import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('home/', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('changepassword/', views.change_password, name='change_password'),
    path('change_profile/', views.change_profile, name='change_profile'),
    path('delete_account/', views.delete_account, name='delete_account'),
    path('signout/', views.signout, name='signout'),
    path('roles_list/', views.roles_list, name='roles_list'),
    path('create_role/', views.create_role, name='create_role'),
    path('edit_role-account/<int:role_id>/', views.edit_role, name='edit_role'),
    path('delete_role-account/<int:role_id>/', views.delete_role, name='delete_role'),

    
    path('staff_list/', views.staff_list, name='staff_list'),
    path('create_staff_employee/', views.create_staff_employee, name='create_staff_employee'),
    path('edit_staff_employee/<int:user_id>/', views.edit_staff_employee, name='edit_staff_employee'),  
    path('delete_staff_employee-account/<int:user_id>/', views.delete_staff_employee, name='delete_staff_employee'),

    path('associate_permissions/<int:role_id>/', views.associate_permissions, name='associate_permissions'),
]