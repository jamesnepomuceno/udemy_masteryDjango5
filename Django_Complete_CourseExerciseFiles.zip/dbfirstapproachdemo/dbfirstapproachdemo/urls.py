"""
URL configuration for dbfirstapproachdemo project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from dbfirstapproachapp import views
urlpatterns = [
    path("",views.MyHome,name="MyHome"),
    path('admin/', admin.site.urls),
    path('ShowCategories/', views.ShowCategories,name="ShowCategories"),
    path('RawSqlDemo/', views.RawSqlDemo,name="RawSqlDemo"),
    path('StoredProcedureDemo/', views.StoredProcedureDemo,name="StoredProcedureDemo"),
    path('SPWithOutputParametersDemo/', views.SPWithOutputParametersDemo,name="SPWithOutputParametersDemo"),
    path('ExportToCSV/', views.ExportToCSV,name='export_to_csv'),
    path('ExportToJSON/', views.ExportToJSON,name='export_to_json'),
    path('ExportToXLS/', views.ExportToXLS,name='export_to_excel'),
    path('ExportToWord/', views.ExportToWord,name='export_to_word'),
    path('ExportToPDF/', views.ExportToPDF,name='export_to_pdf'),
    path('FilteringQuerySetsDemo/', views.FilteringQuerySetsDemo,name='FilteringQuerySetsDemo'),
    
    path('TwoLevelAccordionDemo/', views.TwoLevelAccordionDemo,name='TwoLevelAccordionDemo'),
    path('MultiLevelAccordionDemo/', views.MultiLevelAccordionDemo,name='MultiLevelAccordionDemo'),


    path('CachingDemo/', views.CachingDemo,name='CachingDemo'),
    path('ShowOrdersUsingCTT/', views.ShowOrdersUsingCTT,name='ShowOrdersUsingCTT'),

    
]
