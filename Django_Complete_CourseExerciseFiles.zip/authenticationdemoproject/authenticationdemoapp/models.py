
# from django.db import models

# Create your models here.
# from django.contrib.auth.models import AbstractUser
# from django.db import models

# class CustomUser(AbstractUser):    
#     

#      COUNTRY_CHOICES = [
#          ('US', 'United States'),
#          ('UK', 'United Kingdom'),
#          ('IN', 'India'),
#          ('AU', 'Australia'),
        
#      ]

#      country = models.CharField(max_length=2, choices=COUNTRY_CHOICES)
#      address = models.CharField(max_length=30, blank=True)