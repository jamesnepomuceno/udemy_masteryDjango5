
from django.db.models.signals import pre_save, post_save, pre_delete, post_delete
from django.dispatch import receiver
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.conf import settings


# Signal to handle pre-save event for User model
@receiver(pre_save, sender=User,dispatch_uid="my_unique_identifier1")
def pre_save_user(sender, instance, **kwargs):
    # Add your pre-save logic for User here
    print(f'Pre-save for User "{instance}".')

@receiver(post_save, sender=User,dispatch_uid="my_unique_identifier2")
def post_save_user(sender, instance, created, **kwargs):
     if created:
        # This is triggered only for new instances
        print(f'User "{instance}" has been created.')

        subject = 'Welcome to UDEMY'
        message = 'We are highly delighted to see you with us!'

        send_mail(
            subject,
            message,
            settings.EMAIL_HOST_USER,
            [instance.email],
            fail_silently=False,
        )

     else:
        # This is triggered for updates to existing instances
        print(f'User "{instance}" has been updated.')

@receiver(pre_delete, sender=User,dispatch_uid="my_unique_identifier3")
def pre_delete_user(sender, instance, **kwargs):
    print(f"Pre-Delete Signal: User '{instance.username}' is about to be deleted.")


@receiver(post_delete, sender=User,dispatch_uid="my_unique_identifier4")
def post_delete_user(sender, instance, **kwargs):
    print(f"Post-Delete Signal: User '{instance.username}' has been deleted.")
    

