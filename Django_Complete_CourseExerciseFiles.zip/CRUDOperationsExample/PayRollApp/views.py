
from django.http import HttpResponseRedirect, JsonResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from PayRollApp.forms import EmployeeForm, PartTimeEmployeeForm, PartTimeEmployeeFormSet,OnSiteEmployeesForm

from PayRollApp.models import Employee, PartTimeEmployee,State,City

from django.core.paginator import Paginator, PageNotAnInteger
from django.conf import settings
from django.db.models import Q
from django.db import transaction


# Create your views here.

def EmployeesList(request):
    #Employees=Employee.objects.all()  
    Employees = Employee.objects.select_related('EmpDepartment','EmpCountry').all()
    print(Employees.query)

    TemplateFile="PayRollApp/EmployeesList.html"
    Dict={"Employees":Employees}
    return render(request,TemplateFile,Dict)

def EmployeeDetails(request,id):
    TemplateFile="PayRollApp/EmployeeDetails.html"
    #employee = Employee.objects.get(id=id)          
    employee = Employee.objects.select_related('EmpDepartment','EmpCountry').all().filter(id=id)
    Dict={"employee":employee[0]}   
    return render(request,TemplateFile,Dict)

def EmployeeDelete(request,id):
    TemplateFile="PayRollApp/EmployeeDelete.html"
    #employee = Employee.objects.get(id=id)
    employee = Employee.objects.select_related('EmpDepartment','EmpCountry').all().filter(id=id)
    Dict={"Employee":employee[0]}   

    if request.method == "POST":
        employee.delete()
        return redirect('EmployeesList')


    return render(request,TemplateFile,Dict)


def EmployeeUpdate(request,id):
    TemplateFile="PayRollApp/EmployeeUpdate.html"
    #employee = Employee.objects.get(id=id)  

    employee = Employee.objects.select_related('EmpDepartment','EmpCountry').all().filter(id=id)
    
    for emp in employee:
        #form = EmployeeForm(instance=employee)
        form = EmployeeForm(instance=emp)
        Dict={"form":form}

    if request.method=="POST":        
        form = EmployeeForm(request.POST,instance=emp)
        if form.is_valid():
            form.save()
        return redirect("EmployeesList")
    
    return render(request,TemplateFile,Dict)

def EmployeeInsert(request):
    TemplateFile="PayRollApp/EmployeeInsert.html"
    form=EmployeeForm()

    if request.method == "POST":
        form=EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('EmployeesList')
    
    return render(request,TemplateFile,{'form':form})


def BulkInsertDemo(request):
    extra_forms = 10
    forms = [PartTimeEmployeeForm(request.POST or None, prefix=f'employee-{i}') for i in range(extra_forms)]
    Status=""

    if request.method == 'POST':
        for form in forms:
            if form.is_valid() and form.cleaned_data.get('FirstName', ''):
                form.save()
                Status="Records were inserted successfully.."


    return render(request, 'PayRollApp/parttimeemployee_list.html', {'forms': forms, 'extra_forms': range(extra_forms),"Status":Status})

def NewBulkInsertDemo(request):
    

    if request.method == 'POST':
        formset = PartTimeEmployeeFormSet(request.POST, prefix='employee')
        if formset.is_valid():
            employees = formset.save(commit=False)
            PartTimeEmployee.objects.bulk_create(employees)
            return redirect('NewBulkInsert')
    else:
        formset = PartTimeEmployeeFormSet(queryset=PartTimeEmployee.objects.none(), prefix='employee')


    return render(request,"PayRollApp/NewBulkInsert.html",{'formset': formset})
















def BulkUpdateDemo(request):
    employees=PartTimeEmployee.objects.all()

    forms = [PartTimeEmployeeForm(request.POST or None, instance=employee, prefix=f'employee-{employee.id}') for employee in employees]

    if request.method=='POST':
        updated_data=[]
        for form in forms:
            if form.is_valid():
                employee=form.instance
                employee.FirstName=form.cleaned_data['FirstName']
                employee.LastName=form.cleaned_data['LastName']
                employee.TitleName=form.cleaned_data['TitleName']
                updated_data.append(employee)

        PartTimeEmployee.objects.bulk_update(updated_data,['FirstName','LastName','TitleName'])


    return render(request,'PayRollApp/BulkUpdate.html',{'forms': forms, 'employees': employees})


def BulkDeleteDemo(request):
    employees=PartTimeEmployee.objects.all()

    if request.method=='POST':
        selected_ids=request.POST.getlist('selected_ids')

        if selected_ids:
            PartTimeEmployee.objects.filter(pk__in=selected_ids).delete()
            return redirect('BulkDeleteDemo')

    return render(request,'PayRollApp/BulkDelete.html',{'employees': employees})


def DeleteUsingRadio(request):
     employees=PartTimeEmployee.objects.all()

     if request.method=='POST':
         selected_id=request.POST.get('selected_id')
         if selected_id:
             PartTimeEmployee.objects.filter(pk=selected_id).delete()
             return redirect('DeleteUsingRadio')


     return render(request,'PayRollApp/DeleteUsingRadio.html',{'employees': employees})

    
def PageWiseEmployeesList(request):
    page_size = int(request.GET.get('page_size', getattr(settings, 'PAGE_SIZE', 5)))
    page = request.GET.get('page', 1)

    search_query = request.GET.get('search', '')

     # Get the sorting parameters from the request's query parameters
    sort_by = request.GET.get('sort_by', 'id')
    sort_order = request.GET.get('sort_order', 'asc')

    valid_sort_fields = ['id', 'FirstName', 'LastName', 'TitleName']
    if sort_by not in valid_sort_fields:
        sort_by = 'id'
     

    #employees = PartTimeEmployee.objects.all()
     # Query employees based on the search query
    employees = PartTimeEmployee.objects.filter(
        Q(id__icontains=search_query) |
        Q(FirstName__icontains=search_query) |
        Q(LastName__icontains=search_query) |
        Q(TitleName__icontains=search_query)
    )

      # Apply sorting
    if sort_order == 'desc':
        employees = employees.order_by(f'-{sort_by}')
    else:
        employees = employees.order_by(sort_by)


     
    paginator = Paginator(employees, page_size)

    try:
        employees_page = paginator.page(page)
    except PageNotAnInteger:        
        employees_page = paginator.page(1)

    return render(request, 'PayRollApp/PageWiseEmployees.html', 
                  {'employees_page': employees_page, 
                   'page_size': page_size,
                   'search_query': search_query,
                    'sort_by': sort_by,
                    'sort_order': sort_order,
                   })


def TransactionDemo(request):
    try:
        with transaction.atomic():
            employee=PartTimeEmployee.objects.create(FirstName="Jacques",LastName="Kallis",TitleName="Bowler")    
            employee=PartTimeEmployee.objects.create(FirstName="Herb",LastName="Dean",TitleName="Referee")
            employee=PartTimeEmployee.objects.create(FirstName="Ruthless",LastName="Rony",TitleName="Boxer")
            employee=PartTimeEmployee.objects.create(FirstName="Novak",LastName="Novak Djokovic",TitleName="Tennis")	
            employee=PartTimeEmployee.objects.create(Firstame="Michael",LastName="Chang",TitleName="Tennis")
    except Exception as e:
            return render(request,"PayRollApp/TransactionDemo.html",{"Message":str(e)})

    return render(request,"PayRollApp/TransactionDemo.html",{"Message":"Success!!!"})   


def cascadingselect(request):
    employee_form = OnSiteEmployeesForm()
    

    if request.method == 'POST':
        employee_form = OnSiteEmployeesForm(request.POST)
        if employee_form.is_valid():
            employee_form.save()
            return JsonResponse({'success': True})

    return render(request, 'PayRollApp/CascadingDemo.html', {'employee_form': employee_form}) 

def load_states(request):
    country_id = request.GET.get('country_id')    
    states = State.objects.filter(country_id=country_id).values('id', 'name')
    return JsonResponse(list(states), safe=False)

def load_cities(request):
    state_id = request.GET.get('state_id')
    cities = City.objects.filter(state_id=state_id).values('id', 'name')
    return JsonResponse(list(cities), safe=False)

	
    
def cookie_page(request):
    cookies = request.COOKIES
    return render(request, 'PayRollApp/cookie_page.html', {'cookies': cookies})
	 

def add_cookie(request):
    if request.method == 'POST':
        cookie_name = request.POST.get('cookie_name')
        cookie_value = request.POST.get('cookie_value')
        response = HttpResponseRedirect(reverse('cookie_page'))  
        response.set_cookie(cookie_name, cookie_value,1200)
        return response
    return JsonResponse({'message': 'Invalid request method'})


def clear_cookies(request):
    response = HttpResponseRedirect(reverse('cookie_page'))
    for key in request.COOKIES:
        response.delete_cookie(key)
    return response

def read_cookie(request, cookie_name):
    cookie_value = request.COOKIES.get(cookie_name, None)
    return render(request, 'PayRollApp/read_cookie.html', {'cookie_name': cookie_name, 'cookie_value': cookie_value})


def delete_cookie(request, cookie_name):
    response = HttpResponseRedirect(reverse('cookie_page'))  
    response.delete_cookie(cookie_name)
    return response



def session_page(request):
    session_data = request.session.items()
    return render(request, 'PayRollApp/session_page.html', {'session_data': session_data})


def add_session(request):
    if request.method == 'POST':
        session_key = request.POST.get('session_key')
        session_value = request.POST.get('session_value')       


        request.session[session_key] = session_value 
        response = HttpResponseRedirect(reverse('session_page')) 
        return response
    
    return JsonResponse({'message': 'Invalid request method'})


def clear_sessions(request):
    request.session.flush()
    response = HttpResponseRedirect(reverse('session_page'))
    return response

def read_session(request, session_key):
    session_value = request.session.get(session_key, None)
    return render(request, 'PayRollApp/read_session.html', {'session_key': session_key, 'session_value': session_value})

def delete_session(request, session_key):
    if session_key in request.session:
        response = HttpResponseRedirect(reverse('session_page')) 
        del request.session[session_key]
        return response
    else:
        return JsonResponse({'message': 'Session not found'})
    


def MyHome(request):
    return render(request,"PayRollApp/Index.html")

