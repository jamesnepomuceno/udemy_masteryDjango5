from django.urls import path

from PayRollApp import views

urlpatterns=[
path("",views.MyHome,name="MyHome"),
path("EmployeesList",views.EmployeesList,name="EmployeesList"),
path("EmployeeDetails/<int:id>",views.EmployeeDetails,name="EmployeeDetails"),
path("EmployeeDelete/<int:id>",views.EmployeeDelete,name="EmployeeDelete"),
path("EmployeeUpdate/<int:id>",views.EmployeeUpdate,name="EmployeeUpdate"),
path("EmployeeInsert",views.EmployeeInsert,name="EmployeeInsert"),
path("BulkEmployeeInsert",views.BulkInsertDemo,name="BulkEmployeeInsert"),
path("BulkUpdate",views.BulkUpdateDemo,name="BulkUpdate"),
path("BulkDeleteDemo",views.BulkDeleteDemo,name="BulkDeleteDemo"),
path("DeleteUsingRadio",views.DeleteUsingRadio,name="DeleteUsingRadio"),
path("NewBulkInsert",views.NewBulkInsertDemo,name="NewBulkInsert"),
path("PageWiseEmployeesList",views.PageWiseEmployeesList,name="PageWiseEmployeesList"),
path("TransactionDemo",views.TransactionDemo,name="TransactionDemo"),

path('cascadingselect/',views.cascadingselect,name='cascadingselect'),
path('load_states/', views.load_states, name='load_states'),
path('load_cities/', views.load_cities, name='load_cities'),


path('cookie_page/', views.cookie_page, name='cookie_page'),
path('add_cookie/', views.add_cookie, name='add_cookie'),
path('clear_cookies/', views.clear_cookies, name='clear_cookies'),
path('read_cookie/<str:cookie_name>/', views.read_cookie, name='read_cookie'),
path('delete_cookie/<str:cookie_name>/', views.delete_cookie, name='delete_cookie'),

path('session_page/', views.session_page, name='session_page'),
path('add_session/', views.add_session, name='add_session'),
path('clear_sessions/', views.clear_sessions, name='clear_sessions'),
path('read_session/<str:session_key>/', views.read_session, name='read_session'),
path('delete_session/<str:session_key>/', views.delete_session, name='delete_session'),
]