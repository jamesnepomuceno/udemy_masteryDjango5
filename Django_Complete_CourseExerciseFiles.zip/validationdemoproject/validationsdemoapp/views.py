from django.shortcuts import render

from validationsdemoapp.forms import UserRegistrationForm

# Create your views here.

def SignUp(request):

    if request.method == "POST":        
        form=UserRegistrationForm(request.POST)      
        
        if form.is_valid():
            print("form validations are successful")
           
            form.save()
            return render(request,"validationsdemoapp/Home.html")
    else:
        form=UserRegistrationForm()

    return render(request,"validationsdemoapp/SignUp.html",{"form":form})