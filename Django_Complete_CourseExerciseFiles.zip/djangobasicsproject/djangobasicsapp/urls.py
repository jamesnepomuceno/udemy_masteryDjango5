
from django.urls import path

from . import views

urlpatterns=[

path("",views.MyHome,name="MyHome"),
path("Index",views.Index,name="Index"),

path("Home",views.Home,name="Home"),
path("ShowMessages",views.ShowMoreMessages,name="ShowMessages"),
path("UseVariables",views.UseVariableAsResponse,name="UseVariables"),
path("GetRequestDemo",views.GetRequestVariables,name="GetRequestDemo"),
path("ShowTime",views.ShowDateTimeInfo,name="ShowTime"),
path("loggingdemo",views.LoggingExample,name="LoggingExample"),



path("IfTagDemo",views.iftagdemo,name="IfTagDemo"),
path("ShowProducts",views.ShowProducts,name="ShowProducts"),
path("ShowUsers",views.LoadUsers,name="ShowUsers"),
path("ShowUsers2",views.LoadUsers2,name="ShowUsers2"),
path("ShowUsersDetails",views.LoadUserDetails,name="ShowUsersDetails"),





path("PassModel",views.PassModelToTemplate,name="PassModel"),
path("BIFDemo",views.BuiltInFiltersDemo,name="BIFDemo"),
path("CustomFiltersDemo",views.CustomFiltersDemo,name="CustomFiltersDemo"),
path("TestStaticFiles",views.TestStaticFiles,name="TestStaticFiles"),

]