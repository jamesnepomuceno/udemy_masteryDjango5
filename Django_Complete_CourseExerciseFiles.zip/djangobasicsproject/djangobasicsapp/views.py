import datetime
from django.http import HttpResponse
from django.shortcuts import render
import requests

from djangobasicsapp.models import Authors

# Create your views here.

#Function based view
def Home(request):
    return HttpResponse("<h1>Hello World From Django 5.</h1>")


def ShowMoreMessages(request):
    return HttpResponse("<h1>Hello World From Django 5.</h1><h2>Hello World From Django 5.</h2><h3>Hello World From Django 5.</h3><h4>Hello World From Django 5.</h4><h5>Hello World From Django 5.</h5><h6>Hello World From Django 5.</h6>")


def UseVariableAsResponse(request):
    Message="<h1>Welcome To Django Development.</h1>"
    Message += "<h1>Welcome To Django Development.</h1>"
    Message += "<h2>Welcome To Django Development.</h2>"
    Message += "<h3>Welcome To Django Development.</h3>"
    Message += "<h4>Welcome To Django Development.</h4>"
    Message += "<h5>Welcome To Django Development.</h5>"
    Message += "<h6>Welcome To Django Development.</h6>"
    return HttpResponse(Message)


def GetRequestVariables(request):
    #GET, POST,PUT,DELETE,PATCH
    Message=''
    if(request.method == 'GET'):
        if(request.GET.get('Message')):
            Message=request.GET.get('Message')
        else:
            Message="<h1>You havent supplied value for Message Parameter...</h1>"

        if(request.GET.get('Country')):
            Message += request.GET.get('Country')
        else:
            Message += "<h1>You havent supplied value for Country Parameter...</h1>"

    return HttpResponse(Message)


def ShowDateTimeInfo(request):
    TodaysDate=datetime.datetime.now()
    templatefilename="djangobasicsapp/ShowTimeInfo.html"
    dict={'TodaysDate':TodaysDate}
    return render(request,templatefilename,context=dict)


import logging
from datetime import date,datetime

def LoggingExample(request):    
    logging.debug(f"Debug : I just entered into the View..{datetime.now()}")
    logging.info(f"Info : Confirmation that things are working as expected.")
    logging.warning(f"Warning : An indication that something unexpected happened")
    logging.error(f"Error : Due to a more serious problem, the software has not been able to perform some function.")
    logging.critical(f"Critical : A serious error, indicating that the program itself may be unable to continue running.")
    
    
    custom_logger = logging.getLogger('mycustom_logger')
    custom_logger.debug(f"Debug : I just entered into the View..{datetime.now()}")
    custom_logger.info(f"Info : Confirmation that things are working as expected.")
    custom_logger.warning(f"Warning : An indication that something unexpected happened")
    custom_logger.error(f"Error : Due to a more serious problem, the software has not been able to perform some function.")
    custom_logger.critical(f"Critical : A serious error, indicating that the program itself may be unable to continue running.")

    
    
    return HttpResponse("Logging Demo")

def iftagdemo(request):
    data={'name':'Jimmy Anderson','isVisible':True,'loggedIn': False,'countryCode':'US','workExperience':15,'stateCode':'OH'}
    templatefilename="djangobasicsapp/IfTagDemo.html"
    dict={"Data":data}
    return render(request,templatefilename,dict)

def ShowProducts(request):    
    Products=[]

    Processors = [
    {'Category': 'AMD', 'processors': ['Ryzen 3990', 'Ryzen 3970','Ryzen 3960','Ryzen 3950']},
    {'Category': 'Intel', 'processors':['Xeon 8362', 'Xeon 8358','Xeon 8380']}
  ];
    
    Products.append( {'productID':1,'productName':"AMD Ryzen 3990",'quantity':100,'unitsInStock':50,'disContinued':False,'cost':3000})
    Products.append( {'productID':2,'productName':"AMD Ryzen 3980",'quantity':100,'unitsInStock':50,'disContinued':False,'cost':4000})
    Products.append( {'productID':3,'productName':"AMD Ryzen 3970",'quantity':100,'unitsInStock':50,'disContinued':False,'cost':5000})
    Products.append( {'productID':4,'productName':"AMD Ryzen 3960",'quantity':100,'unitsInStock':50,'disContinued':False,'cost':6000})
    Products.append( {'productID':5,'productName':"AMD Ryzen 3950",'quantity':100,'unitsInStock':50,'disContinued':False,'cost':7000})
    Products.append( {'productID':6,'productName':"AMD Ryzen 3940",'quantity':100,'unitsInStock':50,'disContinued':True,'cost':8000})
    Products.append( {'productID':7,'productName':"AMD Ryzen 3930",'quantity':100,'unitsInStock':50,'disContinued':True,'cost':9000})
    Products.append( {'productID':8,'productName':"AMD Ryzen 3920",'quantity':100,'unitsInStock':50,'disContinued':True,'cost':10000})
    TemplateFile='djangobasicsapp/ShowProducts.html'    
    dict={"Products":Products,"TotalProducts":len(Products),"Processors":Processors}
    return render(request,TemplateFile,dict)


def LoadUsers(request):
    templatefilename="djangobasicsapp/ShowUsers.html"
    response=CallRestAPI()
    dict={"users":response.json()}
    return render(request,templatefilename,dict)


def CallRestAPI():
     BASE_URL = 'https://fakestoreapi.com'
     response = requests.get(f"{BASE_URL}/users")
     return(response)


def Index(request):
    return render(request,'djangobasicsapp/Index.html')

def LoadUsers2(request):
    TemplateFile='djangobasicsapp/ShowUsersAsCards.html' 
    image = 'https://i.pravatar.cc';
    response=CallRestAPI()
    dict={"users":response.json(),"image":image}
    return render(request,TemplateFile,dict)


def CallRestAPI2(userid):
     BASE_URL = 'https://fakestoreapi.com'
     response = requests.get(f"{BASE_URL}/users/{userid}")
     return(response)

def LoadUserDetails(request):

    if request.method == "POST":
        counter=int(request.POST.get("useridcounter"))

        if(request.POST.get("btnNext")):
            counter=counter+1
            if counter >= 11:
                counter=1
        elif(request.POST.get("btnPrevious")):           
            counter=counter - 1
            if counter==0:
                counter=1
    
    else:
        counter=1     

    templatefilename="djangobasicsapp/ShowUserDetails.html"
    response=CallRestAPI2(counter)
    image = 'https://i.pravatar.cc';
    dict={"user":response.json(),"image":image}        
    return render(request, templatefilename, dict)




















def PassModelToTemplate(request):
    #instantiated model class object
    obj=Authors("Chad Mendis","USA","UFC")
    templatefilename="djangobasicsapp/PassModel.html"

    AuthorsList=[]
    AuthorsList.append(Authors('Lesnor', "USA","UFC"))
    AuthorsList.append(Authors('Nate Diaz', "USA","UFC"))
    AuthorsList.append(Authors('Nick Diaz', "USA","UFC"))
    AuthorsList.append(Authors('Johnson', "USA","UFC"))
    AuthorsList.append(Authors('Connors McGregor', "USA","UFC"))
    AuthorsList.append(Authors('Michael Chandler', "USA","UFC"))


    #Array of Objects
    Dict={"Author":obj,"Authors":AuthorsList}
    return render(request,templatefilename,Dict)

def BuiltInFiltersDemo(request):
    Processors=[
    {"name": "Ryzen 3970", "cores": 32},
    {"name": "Ryzen 3950", "cores": 16},
    {"name": "Ryzen 3990", "cores": 64},
                ]
    dict={
        "ProbationPeriod":4,
        "FirstName":"Connors",
        "LastName":"McGregor",
        "PayForFight":123456,
        "FirstQuarter":["Jan","Feb","Mar"],
        "SecondQuarter":["Apr","May","Jun"],
        "FQuarter":[1,2,3],
        "SQuarter":[4,5,6],
        "AboutMe":"i'am Notorious and I'am Ruthless too!",
        "now":datetime.datetime.now(),
        "PreviousFight":"",
        "NextFight":None,   
        "Processors":Processors,
        "Message":"<h1>I am using escape</h1>",
        "WebSite":"https://www.uiacademy.co.in"
    }
    return render(request,"djangobasicsapp/BIFDemo.html",dict)



def CustomFiltersDemo(request):
     webframeworks={        
        'Description':'Django is a Python framework that makes it easier to create dynamic web sites using Python',
        'InDemand':'4.8',
        'PollNumber':57650

        }
     return render(request,"djangobasicsapp/TestCustomFilters.html",webframeworks)

def TestStaticFiles(request):
    return render(request,"djangobasicsapp/TestStaticFiles.html")

def MyHome(request):
    return render(request,"djangobasicsapp/MyHome.html")