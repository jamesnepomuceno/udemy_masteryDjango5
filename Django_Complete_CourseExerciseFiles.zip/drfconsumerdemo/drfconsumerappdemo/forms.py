
from django import forms
import requests


def department_choices():
    response = requests.get("http://localhost:8000/departments_list")
    return response.json()


def country_choices():
    response = requests.get("http://localhost:8000/countries_list")
    return response.json()


class EmployeeForm(forms.Form):    
    FirstName = forms.CharField(max_length=30)
    LastName = forms.CharField(max_length=30)
    TitleName = forms.CharField(max_length=30)
    HasPassport = forms.BooleanField()
    Salary = forms.IntegerField()
    HireDate = forms.DateField()
    Notes = forms.CharField(max_length=200)
    Email = forms.EmailField(max_length=50)
    PhoneNumber = forms.CharField(max_length=20)
    Department = forms.ChoiceField(choices=department_choices())
    Country = forms.ChoiceField(choices=country_choices())

    class Meta:       
        fields = [
            "FirstName",
            "LastName",
            "TitleName",
            "HasPassport",
            "Salary",
            "HireDate",
            "Notes",
            "Email",
            "PhoneNumber",
            "Department",
            "Country",
        ]
        widgets = {
             'BirthDate': forms.widgets.DateInput(attrs={'type': 'date'}),
             'HireDate': forms.widgets.DateInput(attrs={'type': 'date'}),
         }

