

# urls.py
from django.urls import path
from chartsdemoapp import views

urlpatterns = [
    path('', views.Home, name='home'),   
    path('get_chart_data/<str:chart_type>/', views.get_chart_data, name='get_chart_data'),
]
