from django.contrib import admin

from chartsdemoapp.models import SalesData

# Register your models here.

admin.site.register(SalesData)