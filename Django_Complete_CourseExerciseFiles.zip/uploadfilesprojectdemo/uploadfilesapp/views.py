import base64
import os
from django.shortcuts import get_object_or_404, redirect, render

from uploadfilesapp.forms import EmployeeForm
from django.contrib import messages

from uploadfilesapp.models import Employee, EmployeeCertificate
# Create your views here.

def employee_create(request):    

    if request.method == 'POST':
        employee_form = EmployeeForm(request.POST, request.FILES)
        certificate_files = request.FILES.getlist('certificate_files')
      

        if employee_form.is_valid():
            
            #employee = employee_form.save()

            employee = employee_form.save(commit=False)

             # Handle PAN card picture
            pan_card_pic = request.FILES.get('pan_card_pic_blob')
            if pan_card_pic:
                employee.pan_card_pic_blob = pan_card_pic.read()

            employee.save()
        



            if len(certificate_files) > 10:
                messages.error(request, 'You can upload a maximum of 10 certificate files.')
                return redirect('employee_create')
        
         # Create a folder for the employee using employee id
            employee_folder = os.path.join('employee_files', 'certificates', str(employee.id))
            os.makedirs(employee_folder, exist_ok=True)


            for idx, certificate_file in enumerate(certificate_files, start=1):
                original_extension = os.path.splitext(certificate_file.name)[1]

                 # Rename and save the certificate file with the desired format
                new_filename = f'{employee.id}_{employee.first_name}_{idx}{original_extension}'
                new_file_path = os.path.join(employee_folder, new_filename)

                # Save the certificate file
                with open(new_file_path, 'wb+') as destination:
                    for chunk in certificate_file.chunks():
                        destination.write(chunk)
                
                EmployeeCertificate.objects.create(
                    employee=employee,
                    certificate_file=new_file_path,  # Save the path, not the File object
                )           

    else:
        employee_form = EmployeeForm()
    return render(request, 'uploadfilesapp/employee_create.html', {'employee_form': employee_form})


def employee_list(request):
    employees = Employee.objects.all()

    # Calculate remaining certificates for each employee
    employee_data = []
    for employee in employees:
        existing_certificates = len(EmployeeCertificate.objects.filter(employee=employee))
        remaining_certificates = 10 - existing_certificates
        employee_data.append({'employee': employee, 'remaining_certificates': remaining_certificates})

    
    return render(request, 'uploadfilesapp/employee_list.html', {'employee_data': employee_data})



def employee_details(request, employee_id):
    employee = get_object_or_404(Employee, pk=employee_id)
    certificates = EmployeeCertificate.objects.filter(employee=employee)

    # Convert the binary image data to base64
    pan_card_pic_base64 = base64.b64encode(employee.pan_card_pic_blob).decode('utf-8') if employee.pan_card_pic_blob else None

    #return render(request, 'uploadfilesapp/employee_details.html', 
                  #{'employee': employee, 'certificates': certificates})
    
    return render(request, 'uploadfilesapp/employee_details.html', 
                  {'employee': employee, 
                   'pan_card_pic_base64': pan_card_pic_base64, 
                   'certificates': certificates})