from django.contrib import admin

from drfproviderdemoapp.models import Employee

# Register your models here.
admin.site.register(Employee)