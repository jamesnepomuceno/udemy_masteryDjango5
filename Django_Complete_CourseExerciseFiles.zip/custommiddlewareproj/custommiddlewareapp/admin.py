from django.contrib import admin

from custommiddlewareapp.models import PublicHoliday

# Register your models here.
admin.site.register(PublicHoliday)