
from django.http import HttpResponseForbidden
from datetime import datetime, time

from custommiddlewareapp.models import PublicHoliday


class MaintenanceMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        #  if self.is_public_holiday():
        #       return HttpResponseForbidden("Site is not accessible on this public holiday.")
        
        #  if self.is_weekend():
        #     return HttpResponseForbidden("Site is not accessible on weekends. Please try on weekdays.") 
         
         if self.is_maintenance_time():
             return HttpResponseForbidden("Site is in maintenance. Please try after some time.")
          

         response = self.get_response(request)

         return response
         

    # def is_public_holiday(self):                
    #      today = datetime.now().date()
    #      return PublicHoliday.objects.filter(date=today).exists()
    
    # def is_weekend(self):                
    #     today = datetime.now().date()
    #     return today.weekday() in [3, 6] 

    def is_maintenance_time(self):  
         currenthour=datetime.now().hour
         return(currenthour >= 14 and currenthour <= 18)



    
